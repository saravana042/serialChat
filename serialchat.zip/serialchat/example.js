var React = require("react");
var ReactDOM = require("react-dom");
var createReactClass = require("create-react-class");
var AmCharts = require("@amcharts/amcharts3-react");


// Generate random data
function generateData() {
  var firstDate = new Date();

  var dataProvider = [];

  for (var i = 0; i < 100; ++i) {
    var date = new Date(firstDate.getTime());

    date.setDate(i);

    dataProvider.push({
      date: date,
      value: Math.floor(Math.random() * 100)
    });
  }

  return dataProvider;
}


// Component which contains the dynamic state for the chart
var Chart = createReactClass({
  getInitialState: function () {
    return {
      dataProvider: generateData(),
      timer: null
    };
  },

  componentDidMount: function () {
    var self = this;

    self.setState({
      // Update the chart dataProvider every 3 seconds
      timer: setInterval(function () {
        self.setState({
          dataProvider: generateData()
        });
      }, 3000)
    });
  },

  componentWillUnmount: function () {
    clearInterval(this.state.timer);
  },

  render: function () {
    // Render the chart
    return React.createElement(AmCharts.React, {
  "type": "serial",
  "categoryField": "category",
  "startDuration": 1,
  "categoryAxis": {
    "gridPosition": "start"
  },
  "trendLines": [],
  "graphs": [
    {
      "balloonText": "[[title]] of [[category]]:[[value]]",
      "fillAlphas": 1,
      "id": "AmGraph-1",
      "title": "graph 1",
      "type": "column",
      "valueField": "column-1"
    },
    {
      "balloonText": "[[title]] of [[category]]:[[value]]",
      "fillAlphas": 1,
      "id": "AmGraph-2",
      "title": "graph 2",
      "type": "column",
      "valueField": "column-2"
    }
  ],
  "guides": [],
  "valueAxes": [
    {
      "id": "ValueAxis-1",
      "stackType": "regular",
      "title": "Axis title"
    }
  ],
  "allLabels": [],
  "balloon": {},
  "legend": {
    "enabled": true,
    "useGraphSettings": true
  },
  "titles": [
    {
      "id": "Title-1",
      "size": 15,
      "text": "Chart Title"
    }
  ],
  "dataProvider": [
    {
      "category": "category 1",
      "column-1": 8,
      "column-2": 5
    },
    {
      "category": "category 2",
      "column-1": 6,
      "column-2": 7
    },
    {
      "category": "category 3",
      "column-1": 2,
      "column-2": 3
    }
  ]
});
  }
});


ReactDOM.render(
  React.createElement(Chart, null),
  document.getElementById("root")
);
